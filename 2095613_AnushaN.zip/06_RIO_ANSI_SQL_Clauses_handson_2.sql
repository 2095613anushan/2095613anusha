use anusha;
SELECT * FROM student_info;

SELECT stu_name,Regestration_no,GPA
FROM student_info ,student_result order by GPA desc;

SELECT stu_name
FROM student_info order by stu_name asc;

SELECT Date_of_Birth
FROM student_info order by Date_of_Birth asc;

SELECT regestration_no,stu_name,semester,GPA
FROM student_info ,student_result order by  GPA desc;

  
 SELECT  reg_Number,GPA
 FROM student_result where Is_Eligible ='y' ;
 
 SELECT max( GPA), semester
 FROM student_result group by semester;
 
 SELECT min(GPA),semester
 FROM student_result group by semester;
 
 
 
  

