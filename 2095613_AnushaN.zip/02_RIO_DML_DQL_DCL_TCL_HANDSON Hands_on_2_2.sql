use anusha;
create table Student_info(
Regestration_no varchar(30),
Stu_Name varchar(40),
Branch varchar(30),
Contact double,
Date_of_Birth date,
Date_of_Joining date,
Address varchar(200),
Email_id varchar(100)
);

create table Subject_Master(
Subject_Code varchar(30),
Subject_Name varchar(60),
Wei_for_GPA int
);

create table Student_marks(
Reg_Number varchar(20),
Subject_Code varchar(10),
Semester int,
marks int
);

create table Student_Result(
Reg_Number varchar(10),
Semester int,
GPA float,
Is_Eligible char(3)
);

insert into student_info values('MC101301','James','MCA',9714589787,'1984-01-12','2010-07-08','No 10,South Block,Nivea','james.mca@yahoo.com'),
('BEC111402','Manio','ECE',8912457875,'1983-02-23','2011-06-25','8/12,Park View,Sieera','manioma@gmail.com'),
('BEEI1001204','Mike','EI',8974567897,'1983-02-10','2010-08-25','Cross villa,NY','mike.james@ymail.com'),
('MB111305','Paulson','MBA',8547986123,'1984-12-13','2010-08-08','Lake view,NJ','paul.son@rediffmail.com');

insert into Subject_Master values('EE01DCF',' DCF',' 30'),
('EC02MUP',' Microprocessor',' 40'),
('MC06DIP',' Digital Image Processing',' 30'),
('MB03MAR',' Marketing Techniques',' 20'),
('EI05IP',' Instrumentation Precision',' 40'),
('CPSC02DS',' Data Structures',' 40');


insert into student_marks values('BEEI101204',' EE01DCF',' 1',' 85'),
('BEEI101204',' EC02MUP',' 1',' 78'),
('BEEI101204',' MC06DIP',' 1',' 80'),
('BEEI101204',' MB03MAR',' 2',' 75'),
('BEEI101204',' EI05IP',' 2',' 65'),
('BEEI101204',' CPSC02DS',' 2',' 75'),
('MB111305',' EE01DCF',' 1',' 65'),
('MB111305',' EC02MUP',' 1',' 68'),
('MB111305',' MC06DIP',' 1',' 63'),
('MB111305',' MB03MAR',' 2',' 85'),
('MB111305',' EI05IP',' 2',' 74'),
('MB111305',' CPSC02DS',' 2',' 62');


insert into student_result values('MC101301',' 1',' 7.5',' Y'),
('BEC111402',' 1',' 7.1',' Y'),
('BEEI101204',' 1',' 8.3',' Y'),
('BEEI101204',' 2',' 6.9',' N'),
('MB111305',' 1',' 6.5',' N'),
('MB111305',' 2',' 6.8',' N');