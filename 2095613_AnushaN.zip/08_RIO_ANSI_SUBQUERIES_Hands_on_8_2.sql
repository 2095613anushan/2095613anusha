use anusha;
select Regestration_no,Stu_Name from student_info,student_marks
where student_marks >(select max(marks) from student_marks);

select Regestration_no,Stu_Name from student_info
where student_mark > (select max(student_mark) from student_marks where Subject_Code='EI05IP');

select Regestration_no,Stu_Name from student_info
where student_mark IN
(select student_mark from student_marks  group by student_mark  order by  student_mark desc limit 1,1); 

select Regestration_no,Stu_Name from student_info
where student_mark > (select avg(student_mark) from student_marks where Subject_Code='EI05IP');