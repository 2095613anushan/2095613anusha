create table trainer_info(
Trainer_Id varchar(30) not null primary key check(Trainer_Id like 'F%'),
Salutation varchar(7) not null,
Trainer_Name varchar(30) not null,
Trainer_Location varchar(30)not null,
Trainer_Track varchar(15) not null,
Trainer_Qualification varchar(100) not null,
Trainer_Experiance int,
Trainer_Email varchar(100) not null,
Trainer_Password varchar(20) not null
);

create table Batch_Info(
Batch_Id varchar(20)not null primary key check(Batch_Id like 'B%'),
Batch_Owner varchar(30)not null,
Batch_BU_Name varchar(30) not null
);

create table Module_Info(
Module_Id varchar(20)not null primary key check(upper(Module_Id)=Module_Id),
Module_Name varchar(40)not null,
Module_Duration int not null
);

create table Associate_Info(
Associate_Id varchar(20)not null primary key check(Associate_Id like 'A%'),
Salutation varchar(7) not null,
Associate_Name varchar(30)not null,
Associate_Location varchar(30) not null,
Associate_Track varchar(15) not null,
Associate_Qualification varchar(200) not null,
Associate_Email varchar(100) not null,
Associate_Password varchar(20) not null
);

create table Questions(
Question_Id varchar(20)not null primary key check(Question_Id like 'Q%'),
Module_Id varchar(20),
 foreign key (Module_Id) REFERENCES Module_Info(Module_Id),
Question_Text varchar(900) not null
);

create table Associate_Status(
Associate_Id varchar(20) not null,
 foreign key (Associate_Id) REFERENCES Associate_Info(Associate_Id),
Module_Id varchar(20) not null,
 foreign key (Module_Id) REFERENCES Module_Info(Module_Id),
Batch_Id varchar(20)not null,
 foreign key (Batch_Id) REFERENCES Batch_Info(Batch_Id),
Trainer_Id varchar(20)not null,
 foreign key (Trainer_Id) REFERENCES Trainer_Info(Trainer_Id),
Start_Date varchar(20),
End_Date varchar(20),
AFeedbackGiven varchar(20),
TFeedbackGiven varchar(20)
);

create table Trainer_Feedback(
Trainer_Id varchar(20)not null,
 foreign key(Trainer_Id) REFERENCES Trainer_Info(Trainer_Id),
Question_Id varchar(20)not null,
 foreign key(Question_Id) REFERENCES Questions(Question_Id),
Batch_Id varchar(20)not null,
 foreign key(Batch_Id) REFERENCES Batch_Info(Batch_Id),
Module_Id varchar(20)not null,
 foreign key (Module_Id) REFERENCES Module_Info(Module_Id),
Trainer_Rating int not null
);

create table Associate_Feedback(
Associate_Id varchar(20)not null,
 foreign key(Associate_Id) REFERENCES Associate_Info(Associate_Id),
Question_Id varchar(20)not null,
 foreign key(Question_Id) REFERENCES Questions(Question_Id),
Module_Id varchar(20)not null,
 foreign key(Module_Id) REFERENCES Module_Info(Module_Id),
Associate_Rating int not null
);



create table product(
product_Id int primary key,
productname varchar(20),
productprice int not null
);

create table user_1(
userID varchar(10) primary key,
product_Id int,
foreign key(product_Id) REFERENCES product(product_Id),
username varchar(20)
);

insert into product values(1,'A Dongle',290);
insert into product values(2,'B Dongle',1250);
insert into product(product_Id,productname) values(3,'C Dongle');

ALTER TABLE user_1
DROP FOREIGN KEY product_Id;