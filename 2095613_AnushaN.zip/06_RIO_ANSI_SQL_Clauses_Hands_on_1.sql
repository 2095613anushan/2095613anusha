
create table Associate1_status(
Associate_Id varchar(20),
Module_Id varchar(20),
AFeedbackGiven varchar(20),
TFeedbackGiven varchar(20),
Start_Date varchar(20),
End_Date varchar(20)
);

insert into Associate1_Status values('A001','O10SQL','B001','F001',"2000-12-15","2000-12-25"),
('A002','O10SQL','B001','F001',"2000-12-15","2000-12-25"),
('A003','O10SQL','B001','F001',"2000-12-15","2000-12-25"),
('A001','O10PLSQL','B002','F002',"2001-2-1","2001-2-12"),
('A002','O10PLSQL','B002','F002',"2001-2-1","2001-2-12"),
('A003','O10PLSQL','B002','F002',"2001-2-1","2001-2-12"),
('A001','J2SE','B003','F003',"2002-8-20","2002-10-25"),
('A002','J2SE','B003','F003',"2002-8-20","2002-10-25"),
('A001','J2EE','B004','F004',"2005-12-1","2005-12-25"),
('A002','J2EE','B004','F004',"2005-12-1","2005-12-25"),
('A003','J2EE','B004','F004',"2005-12-1","2005-12-25"),
('A004','J2EE','B004','F004',"2005-12-1","2005-12-25"),
('A005','JAVAFX','B005','F006',"2005-12-4","2005-12-20"),
('A006','JAVAFX','B005','F006',"2005-12-4","2005-12-20"),
('A006','SQL2008','B006','F007',"2007-6-21","2007-6-28"),
('A007','SQL2008','B006','F007',"2007-6-21","2007-6-28"),
('A002','MSBI08','B007','F006',"2009-6-26","2009-6-29"),
('A003','MSBI08','B007','F006',"2009-6-26","2009-6-29"),
('A004','MSBI08','B007','F006',"2009-6-26","2009-6-29"),
('A002','ANDRD4','B008','F005',"2010-6-5","2010-6-28"),
('A005','ANDRD4','B008','F005',"2010-6-5","2010-6-28"),
('A003','ANDRD4','B009','F005',"2011-8-1","2011-8-20"),
('A006','ANDRD4','B009','F005',"2011-8-1","2011-8-20");

SELECT start_date,end_date, count(associate_id)
from associate1_status group by start_date,end_date;

SELECT start_date,end_date, count(associate_id)
from associate1_status where associate_id ='a002' group by start_date,end_date;

SELECT start_date,end_date
from associate1_status order by start_date asc;

SELECT start_date,end_date , associate_id
from associate1_status order by associate_id,end_date asc;




